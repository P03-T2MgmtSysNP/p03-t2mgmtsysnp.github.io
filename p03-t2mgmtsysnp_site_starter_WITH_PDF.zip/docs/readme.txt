Place your presentation PDF and other documents here, then link them in index.html under the Documentation section.
